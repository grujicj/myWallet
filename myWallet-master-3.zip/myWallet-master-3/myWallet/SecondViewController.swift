//
//  SecondViewController.swift
//  myWallet
//
//  Created by Parrish Miller on 2/27/20.
//  Copyright © 2020 Parrish Miller. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

